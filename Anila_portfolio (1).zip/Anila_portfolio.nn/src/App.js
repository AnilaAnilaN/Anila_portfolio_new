import React, { useState, useEffect } from 'react';
import { FaGithub, FaLinkedin, FaUpwork, FaFileDownload, FaCode, FaServer, FaDatabase, FaTools, FaWordpress, FaPaintBrush, FaLaptopCode, FaMobileAlt, FaRocket,  FaGraduationCap, FaCertificate, FaEnvelope, FaBriefcase, FaUser, FaProjectDiagram, FaCogs, FaComments } from 'react-icons/fa';

const Portfolio = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll('section');
      sections.forEach(section => {
        const sectionTop = section.offsetTop;
        if (window.scrollY >= sectionTop - 100) {
          setActiveSection(section.getAttribute('id'));
        }
      });
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId) => {
    const section = document.getElementById(sectionId);
    if (section) {
      window.scrollTo({
        top: section.offsetTop - 80,
        behavior: 'smooth'
      });
      setIsMenuOpen(false);
    }
  };

  return (
    <div className="font-poppins bg-base-100 text-gray-700">
      {/* Navigation */}
      <header className="fixed w-full bg-white/90 backdrop-blur-sm z-50 shadow-sm">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="text-xl font-bold text-primary">Anila Nawaz</div>
          
          <div className="hidden md:flex justify-center items-center space-x-8">
            {[
              { id: 'home', icon: <FaUser />, text: 'Home' },
              { id: 'about', icon: <FaUser />, text: 'About' },
              { id: 'projects', icon: <FaProjectDiagram />, text: 'Projects' },
              { id: 'skills', icon: <FaCogs />, text: 'Skills' },
              { id: 'services', icon: <FaBriefcase />, text: 'Services' },
              { id: 'contact', icon: <FaEnvelope />, text: 'Contact' }
            ].map(item => (
              <button 
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`flex flex-col items-center p-2 ${activeSection === item.id ? 'text-primary' : 'text-gray-600'} hover:text-primary transition-colors`}
              >
                {item.icon}
                <span className="text-xs mt-1">{item.text}</span>
              </button>
            ))}
          </div>
          
          <div className="flex items-center space-x-4">
            <span className="hidden md:inline-flex items-center px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
              <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
              Available for hire
            </span>
            <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"></path>
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white py-4 px-4 shadow-lg">
            <div className="flex flex-col space-y-4">
              {[
                { id: 'home', text: 'Home' },
                { id: 'about', text: 'About' },
                { id: 'projects', text: 'Projects' },
                { id: 'skills', text: 'Skills' },
                { id: 'services', text: 'Services' },
                { id: 'contact', text: 'Contact' }
              ].map(item => (
                <button 
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`py-2 px-4 rounded-lg ${activeSection === item.id ? 'bg-primary text-white' : 'text-gray-700'} hover:bg-primary hover:text-white transition-colors`}
                >
                  {item.text}
                </button>
              ))}
              <div className="pt-4 border-t border-gray-200">
                <span className="inline-flex items-center px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                  Available for hire
                </span>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center pt-20 pb-16 bg-gradient-to-br from-blue-50 to-cyan-50">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-gray-800">
            Anila <span className="text-primary">Nawaz</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-600 max-w-3xl mx-auto">
            Full Stack Developer & <span className="text-secondary font-semibold">MERN</span> Specialist
          </p>
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm flex items-center">
              <FaCode className="mr-1 text-blue-500" /> React.js
            </span>
            <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm flex items-center">
              <FaServer className="mr-1 text-purple-500" /> Node.js
            </span>
            <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm flex items-center">
              <FaDatabase className="mr-1 text-green-500" /> MongoDB
            </span>
            <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm flex items-center">
              <FaWordpress className="mr-1 text-yellow-500" /> WordPress
            </span>
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            <a href="https://www.upwork.com/freelancers/anilan6" target="_blank" rel="noopener noreferrer" className="btn btn-primary gap-2">
              <FaUpwork className="text-lg" /> Hire me on Upwork
            </a>
            <a href="/resume.pdf" download className="btn btn-outline btn-secondary gap-2">
              <FaFileDownload /> View Resume
            </a>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16 text-gray-800">About Me</h2>
          
          <div className="flex flex-col lg:flex-row gap-12 items-center">
            <div className="lg:w-1/2">
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <h3 className="text-2xl font-bold mb-4 text-gray-800">Professional Summary</h3>
                <p className="mb-6 text-gray-600">
                  Dedicated Full Stack Developer with 2+ years of hands-on experience in MERN stack development. 
                  Proven track record of building scalable web applications with modern technologies including 
                  React, Node.js, Express, and MongoDB.
                </p>
                <p className="mb-6 text-gray-600">
                  Passionate about creating user-centric solutions and collaborating in agile development environments. 
                  Committed to continuous learning and staying current with emerging technologies.
                </p>
                
                <div className="grid grid-cols-2 gap-4 mt-8">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-800">Education</h4>
                    <p className="text-sm text-blue-600">BS Computer Science</p>
                    <p className="text-xs text-blue-500">Virtual University, 2021-2025</p>
                  </div>
                  
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-800">Experience</h4>
                    <p className="text-sm text-green-600">2+ Years</p>
                    <p className="text-xs text-green-500">MERN Stack Development</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="lg:w-1/2">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-2xl shadow-lg">
                  <div className="text-4xl text-primary mb-2">
                    <FaGraduationCap />
                  </div>
                  <h3 className="font-bold mb-2">Education</h3>
                  <p className="text-sm text-gray-600">
                    Bachelor of Science in Computer Science from Virtual University of Pakistan with a CGPA of 3.79/4.00.
                  </p>
                </div>
                
                <div className="bg-white p-6 rounded-2xl shadow-lg">
                  <div className="text-4xl text-secondary mb-2">
                    <FaCertificate />
                  </div>
                  <h3 className="font-bold mb-2">Certifications</h3>
                  <p className="text-sm text-gray-600">
                    React.js Development Course and English Language Proficiency certifications.
                  </p>
                </div>
                
                <div className="bg-white p-6 rounded-2xl shadow-lg">
                  <div className="text-4xl text-accent mb-2">
                    <FaComments />
                  </div>
                  <h3 className="font-bold mb-2">Languages</h3>
                  <p className="text-sm text-gray-600">
                    English (Proficient), Urdu (Native)
                  </p>
                </div>
                
                <div className="bg-white p-6 rounded-2xl shadow-lg">
                  <div className="text-4xl text-primary mb-2">
                    <FaLaptopCode />
                  </div>
                  <h3 className="font-bold mb-2">Interests</h3>
                  <p className="text-sm text-gray-600">
                    Open Source, Technology Blogging, Continuous Learning, UI/UX Design Trends
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-gradient-to-br from-orange-50 to-yellow-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16 text-gray-800">Featured Projects</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Project 1 */}
            <div className="card bg-base-100 shadow-xl overflow-hidden">
              <figure className="h-48 bg-gradient-to-r from-blue-400 to-cyan-400 flex items-center justify-center">
                <FaCode className="text-6xl text-white" />
              </figure>
              <div className="card-body">
                <h3 className="card-title">Real-Time Chat Application</h3>
                <p className="text-gray-600">Comprehensive chat platform with instant messaging using MERN stack and Socket.IO.</p>
                <div className="card-actions justify-between items-center mt-4">
                  <div className="flex flex-wrap gap-2">
                    <span className="badge badge-outline badge-primary">React</span>
                    <span className="badge badge-outline badge-primary">Node.js</span>
                    <span className="badge badge-outline badge-primary">Socket.IO</span>
                  </div>
                  <a href="https://real-time-chat-app-fo6x.onrender.com" target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-sm">Live Demo</a>
                </div>
              </div>
            </div>
            
            {/* Project 2 */}
            <div className="card bg-base-100 shadow-xl overflow-hidden">
              <figure className="h-48 bg-gradient-to-r from-purple-400 to-pink-400 flex items-center justify-center">
                <FaPaintBrush className="text-6xl text-white" />
              </figure>
              <div className="card-body">
                <h3 className="card-title">Bakery UI/UX Design</h3>
                <p className="text-gray-600">Modern and appealing UI design for a bakery website using Figma.</p>
                <div className="card-actions justify-between items-center mt-4">
                  <div className="flex flex-wrap gap-2">
                    <span className="badge badge-outline badge-secondary">Figma</span>
                    <span className="badge badge-outline badge-secondary">UI/UX</span>
                  </div>
                  <a href="https://www.figma.com/design/XAHf4LRTJBEd2pM1e3132h/Figma-basics" target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm">View Design</a>
                </div>
              </div>
            </div>
            
            {/* Project 3 */}
            <div className="card bg-base-100 shadow-xl overflow-hidden">
              <figure className="h-48 bg-gradient-to-r from-green-400 to-teal-400 flex items-center justify-center">
                <FaMobileAlt className="text-6xl text-white" />
              </figure>
              <div className="card-body">
                <h3 className="card-title">Weather Insight Application</h3>
                <p className="text-gray-600">Weather forecasting app with data visualization and geolocation API integration.</p>
                <div className="card-actions justify-between items-center mt-4">
                  <div className="flex flex-wrap gap-2">
                    <span className="badge badge-outline badge-accent">React</span>
                    <span className="badge badge-outline badge-accent">API</span>
                  </div>
                  <a href="https://weather-insight-five.vercel.app" target="_blank" rel="noopener noreferrer" className="btn btn-accent btn-sm">Live Demo</a>
                </div>
              </div>
            </div>
            
            {/* Project 4 */}
            <div className="card bg-base-100 shadow-xl overflow-hidden">
              <figure className="h-48 bg-gradient-to-r from-red-400 to-orange-400 flex items-center justify-center">
                <FaRocket className="text-6xl text-white" />
              </figure>
              <div className="card-body">
                <h3 className="card-title">Portfolio Template</h3>
                <p className="text-gray-600">Modern, responsive portfolio template with smooth animations and interactive UI.</p>
                <div className="card-actions justify-between items-center mt-4">
                  <div className="flex flex-wrap gap-2">
                    <span className="badge badge-outline badge-primary">HTML5</span>
                    <span className="badge badge-outline badge-primary">CSS3</span>
                    <span className="badge badge-outline badge-primary">JavaScript</span>
                  </div>
                  <a href="https://portfolio-template-self-nine.vercel.app" target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-sm">Live Demo</a>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <a href="https://github.com/AnilaAnilaN" target="_blank" rel="noopener noreferrer" className="btn btn-outline btn-secondary gap-2">
              <FaGithub /> View More Projects
            </a>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-gradient-to-br from-cyan-50 to-blue-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16 text-gray-800">Technical Skills</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Frontend */}
            <div className="card bg-white shadow-lg">
              <div className="card-body">
                <div className="flex items-center mb-4">
                  <div className="text-3xl text-blue-500 mr-3">
                    <FaCode />
                  </div>
                  <h3 className="card-title">Frontend</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="badge badge-primary">React.js</span>
                  <span className="badge badge-primary">HTML5</span>
                  <span className="badge badge-primary">CSS3</span>
                  <span className="badge badge-primary">JavaScript</span>
                  <span className="badge badge-primary">Bootstrap</span>
                  <span className="badge badge-primary">Responsive Design</span>
                </div>
              </div>
            </div>
            
            {/* Backend */}
            <div className="card bg-white shadow-lg">
              <div className="card-body">
                <div className="flex items-center mb-4">
                  <div className="text-3xl text-purple-500 mr-3">
                    <FaServer />
                  </div>
                  <h3 className="card-title">Backend</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="badge badge-secondary">Node.js</span>
                  <span className="badge badge-secondary">Express.js</span>
                  <span className="badge badge-secondary">RESTful APIs</span>
                  <span className="badge badge-secondary">PHP</span>
                </div>
              </div>
            </div>
            
            {/* Database */}
            <div className="card bg-white shadow-lg">
              <div className="card-body">
                <div className="flex items-center mb-4">
                  <div className="text-3xl text-green-500 mr-3">
                    <FaDatabase />
                  </div>
                  <h3 className="card-title">Database</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="badge badge-accent">MongoDB</span>
                  <span className="badge badge-accent">MySQL</span>
                  <span className="badge badge-accent">Data Modeling</span>
                </div>
              </div>
            </div>
            
            {/* Tools */}
            <div className="card bg-white shadow-lg">
              <div className="card-body">
                <div className="flex items-center mb-4">
                  <div className="text-3xl text-yellow-500 mr-3">
                    <FaTools />
                  </div>
                  <h3 className="card-title">Tools & CMS</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="badge badge-primary">Git</span>
                  <span className="badge badge-primary">GitHub</span>
                  <span className="badge badge-primary">VS Code</span>
                  <span className="badge badge-primary">Figma</span>
                  <span className="badge badge-primary">WordPress</span>
                  <span className="badge badge-primary">Postman</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-gradient-to-br from-pink-50 to-red-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16 text-gray-800">Services & Rates</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="card bg-white shadow-lg hover:shadow-xl transition-shadow">
              <div className="card-body">
                <div className="text-4xl text-blue-500 mb-4">
                  <FaCode />
                </div>
                <h3 className="card-title">Frontend Development</h3>
                <p className="text-gray-600 mb-4">Custom React applications with responsive design and modern UI/UX principles.</p>
                <div className="card-actions justify-between items-center">
                  <span className="font-bold text-blue-600">$15-20/hour</span>
                  <button className="btn btn-primary btn-sm">Get Quote</button>
                </div>
              </div>
            </div>
            
            <div className="card bg-white shadow-lg hover:shadow-xl transition-shadow">
              <div className="card-body">
                <div className="text-4xl text-purple-500 mb-4">
                  <FaServer />
                </div>
                <h3 className="card-title">Backend Development</h3>
                <p className="text-gray-600 mb-4">Robust Node.js APIs and server-side applications with database integration.</p>
                <div className="card-actions justify-between items-center">
                  <span className="font-bold text-purple-600">$18-25/hour</span>
                  <button className="btn btn-secondary btn-sm">Get Quote</button>
                </div>
              </div>
            </div>
            
            <div className="card bg-white shadow-lg hover:shadow-xl transition-shadow">
              <div className="card-body">
                <div className="text-4xl text-green-500 mb-4">
                  <FaLaptopCode />
                </div>
                <h3 className="card-title">Full Stack MERN</h3>
                <p className="text-gray-600 mb-4">End-to-end web applications using MongoDB, Express, React, and Node.js.</p>
                <div className="card-actions justify-between items-center">
                  <span className="font-bold text-green-600">$20-30/hour</span>
                  <button className="btn btn-accent btn-sm">Get Quote</button>
                </div>
              </div>
            </div>
            
            <div className="card bg-white shadow-lg hover:shadow-xl transition-shadow">
              <div className="card-body">
                <div className="text-4xl text-yellow-500 mb-4">
                  <FaWordpress />
                </div>
                <h3 className="card-title">WordPress Development</h3>
                <p className="text-gray-600 mb-4">Custom WordPress websites with theme customization and plugin integration.</p>
                <div className="card-actions justify-between items-center">
                  <span className="font-bold text-yellow-600">$12-18/hour</span>
                  <button className="btn btn-primary btn-sm">Get Quote</button>
                </div>
              </div>
            </div>
            
            <div className="card bg-white shadow-lg hover:shadow-xl transition-shadow">
              <div className="card-body">
                <div className="text-4xl text-red-500 mb-4">
                  <FaTools />
                </div>
                <h3 className="card-title">Website Maintenance</h3>
                <p className="text-gray-600 mb-4">Ongoing support, updates, and optimization for existing websites.</p>
                <div className="card-actions justify-between items-center">
                  <span className="font-bold text-red-600">$10-15/hour</span>
                  <button className="btn btn-secondary btn-sm">Get Quote</button>
                </div>
              </div>
            </div>
            
            <div className="card bg-white shadow-lg hover:shadow-xl transition-shadow">
              <div className="card-body">
                <div className="text-4xl text-indigo-500 mb-4">
                  <FaRocket />
                </div>
                <h3 className="card-title">Custom Solutions</h3>
                <p className="text-gray-600 mb-4">Tailored web applications and software solutions for specific business needs.</p>
                <div className="card-actions justify-between items-center">
                  <span className="font-bold text-indigo-600">$25-35/hour</span>
                  <button className="btn btn-accent btn-sm">Get Quote</button>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-12 text-center text-gray-600 max-w-3xl mx-auto">
            <p>Rates vary based on project complexity and timeline. Contact me for a detailed quote tailored to your specific requirements.</p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16 text-gray-800">Get In Touch</h2>
          
          <div className="flex flex-col lg:flex-row gap-12">
            <div className="lg:w-1/2">
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <h3 className="text-2xl font-bold mb-6">Send me a message</h3>
                <form className="space-y-6">
                  <div className="form-control">
                    <label className="label">
                      <span className="label-text">Your Name</span>
                    </label>
                    <input type="text" placeholder="Name" className="input input-bordered" />
                  </div>
                  
                  <div className="form-control">
                    <label className="label">
                      <span className="label-text">Your Email</span>
                    </label>
                    <input type="email" placeholder="Email" className="input input-bordered" />
                  </div>
                  
                  <div className="form-control">
                    <label className="label">
                      <span className="label-text">Your Message</span>
                    </label>
                    <textarea className="textarea textarea-bordered h-32" placeholder="Message"></textarea>
                  </div>
                  
                  <div className="form-control mt-6">
                    <button type="submit" className="btn btn-primary">Send Message</button>
                  </div>
                </form>
              </div>
            </div>
            
            <div className="lg:w-1/2">
              <div className="bg-white rounded-2xl p-8 shadow-lg h-full">
                <h3 className="text-2xl font-bold mb-6">Contact Information</h3>
                
                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="text-primary text-xl mr-4">
                      <FaEnvelope />
                    </div>
                    <div>
                      <h4 className="font-semibold">Email</h4>
                      <p className="text-gray-600">anilanawaz531@gmail.com</p>
                      <p className="text-sm text-gray-500">I typically respond within 24 hours</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="text-primary text-xl mr-4">
                      <FaUpwork />
                    </div>
                    <div>
                      <h4 className="font-semibold">Upwork</h4>
                      <p className="text-gray-600">Available for freelance projects</p>
                      <a href="https://www.upwork.com/freelancers/~01c5e7c5e5e5e5e5e5" target="_blank" rel="noopener noreferrer" className="text-sm text-blue-500 hover:underline">View my Upwork profile</a>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="text-primary text-xl mr-4">
                      <FaLinkedin />
                    </div>
                    <div>
                      <h4 className="font-semibold">LinkedIn</h4>
                      <p className="text-gray-600">Connect with me professionally</p>
                      <a href="https://linkedin.com/in/anila-nawaz-dev" target="_blank" rel="noopener noreferrer" className="text-sm text-blue-500 hover:underline">View my LinkedIn profile</a>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="text-primary text-xl mr-4">
                      <FaGithub />
                    </div>
                    <div>
                      <h4 className="font-semibold">GitHub</h4>
                      <p className="text-gray-600">Explore my code and projects</p>
                      <a href="https://github.com/AnilaAnilaN" target="_blank" rel="noopener noreferrer" className="text-sm text-blue-500 hover:underline">View my GitHub profile</a>
                    </div>
                  </div>
                  
                  <div className="pt-6 border-t border-gray-200">
                    <p className="text-sm text-gray-500">
                      <span className="font-semibold">Location:</span> Barmusa, Mandi Bahauddin, Punjab, Pakistan
                    </p>
                    <p className="text-sm text-gray-500 mt-2">
                      <span className="font-semibold">Timezone:</span> PKT (UTC+5)
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <h3 className="text-2xl font-bold">Anila Nawaz</h3>
              <p className="text-gray-400">Full Stack Developer & MERN Specialist</p>
            </div>
            
            <div className="flex space-x-6">
              <a href="https://github.com/AnilaAnilaN" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <FaGithub className="text-2xl" />
              </a>
              <a href="https://linkedin.com/in/anila-nawaz-dev" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <FaLinkedin className="text-2xl" />
              </a>
              <a href="https://www.upwork.com/freelancers/~01c5e7c5e5e5e5e5e5" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <FaUpwork className="text-2xl" />
              </a>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} Anila Nawaz. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Portfolio;